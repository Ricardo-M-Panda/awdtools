# AWD-Kit · MCP & Skills

AWD 攻防比赛用的 MCP 服务与技能包，配合 `AWD-Kit` 主目录使用。

## 目录结构

```
mcp/
├─ awd-tools/          # 自研 Node MCP：nmap / ffuf / nuclei / semgrep / HTTP / 收旗交旗 / 批量执行 / 扫马
│  ├─ server.mjs
│  └─ package.json     # 需 npm install 装 @modelcontextprotocol/sdk
├─ awd-llm/            # 自研 Python MCP：大模型问答 + 流量分析 + payload 复用
│  └─ server.py
├─ awd-mcp-bundle/     # 配置型 bundle 模板（plugin_manager 可选安装方式）
├─ vendor/             # 第三方产物：r2mcp 二进制、GhidraMCP 扩展、wireshark-mcp 源码
├─ install-mcp.ps1     # 一键把 8 个 MCP 写进 DSH profile
└─ enable-rea.ps1      # 可选：启用 rea（255 个工具，占上下文，默认关闭）
skills/
└─ awd-competition/    # AWD 实战手册 skill（收旗/交旗/通防/流量复用）
   └─ SKILL.md
```

## 安装

```powershell
# 1. 装 MCP 依赖（只有 awd-tools 需要）
cd mcp\awd-tools
npm install

# 2. 写入 DSH profile（自动备份原文件）
powershell -ExecutionPolicy Bypass -File ..\install-mcp.ps1

# 3. 装 skill
copy skills\awd-competition "$env:USERPROFILE\.dsh\skills\" -Recurse
```

重启 DSH 后可用 `mcp__awd-tools__kit_info` 验证。

## 本包不含

| 排除项 | 原因 | 如何补 |
|---|---|---|
| `awd-tools/node_modules` | npm 依赖，14 MB | `npm install` |
| `vendor/rea` | rea-agents 源码，100 MB | `npm i -g rea-agents` |
| `memory.jsonl` | 运行时数据 | 自动生成 |

## 依赖的 MCP 服务端（需另外安装）

| server | 来源 |
|---|---|
| `ghidra` | `pip install ghidra_mcp` + Ghidra 扩展（见 vendor） |
| `radare2` | `vendor/r2mcp/r2mcp.exe`（需 radare2 在 PATH） |
| `wireshark` | `pip install pyshark-mcp`（需 tshark） |
| `frida` | `pip install frida-mcp-server` |
| `memory` | `npm i -g @modelcontextprotocol/server-memory` |
| `chrome` | `npm i -g chrome-devtools-mcp` |

## 备注

- `awd-tools` 里 `semgrep_scan` 依赖 semgrep CLI，`web_ffuf` 依赖 kit 内的 ffuf 与字典。
- 所有路径在 `install-mcp.ps1` 里按脚本所在目录自动推导，换机器不用改。
