#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
awd-llm MCP server —— 把「大模型 + 流量分析 + payload 复用」暴露成 MCP 工具

启动：D:\\AWD-Kit\\00-runtime\\python\\python.exe D:\\AWD-Kit\\mcp\\awd-llm\\server.py
传输：stdio

工具：
  llm_chat          通用大模型问答（用比赛给的 API）
  llm_status        检查 LLM 是否配置可用
  analyze_capture   分析抓包 JSONL，出攻击画像 / 漏洞点 / payload
  list_payloads     列出可复用的高分 payload
  replay_payloads   把 payload 重放给其他队伍（必须 confirm=True）
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
KIT = os.path.abspath(os.path.join(HERE, "..", ".."))
TRAFFIC = os.path.join(KIT, "traffic")
sys.path.insert(0, TRAFFIC)

from mcp.server.fastmcp import FastMCP  # noqa: E402

import analyze  # noqa: E402
import replay   # noqa: E402
import llm      # noqa: E402

mcp = FastMCP("awd-llm")


@mcp.tool()
def llm_status() -> str:
    """检查大模型 API 是否已配置、能否连通。返回配置来源与一次探测结果。"""
    c = llm.LLM()
    info = {
        "配置路径": [os.path.join(TRAFFIC, "llm.json"), os.path.expanduser("~/.awd-llm.json")],
        "base_url": c.cfg.get("base_url") or "(未配置)",
        "model": c.cfg.get("model") or "(未配置)",
        "api_key": ("已设置 " + c.cfg["api_key"][:6] + "...") if c.cfg.get("api_key") else "(未配置)",
        "ready": c.ready,
    }
    if c.ready:
        try:
            r = c.chat("只回复两个字：可用", max_tokens=16)
            info["探测"] = f"成功：{r.strip()[:50]}"
        except Exception as e:
            info["探测"] = f"失败：{e}"
    else:
        info["提示"] = "编辑 traffic/llm.json 填 base_url / api_key / model，或设 AWD_LLM_BASE/KEY/MODEL"
    return json.dumps(info, ensure_ascii=False, indent=2)


@mcp.tool()
def llm_chat(prompt: str, system: str = "") -> str:
    """调用比赛提供的大模型 API 做一次问答。用于分析 payload、写 exp、解释报错、生成补丁。

    Args:
        prompt: 你的问题，可以带 payload/代码/流量片段
        system: 可选的人设，例如「你是资深 Web 渗透专家」
    """
    c = llm.LLM()
    if not c.ready:
        return "LLM 未配置：编辑 D:\\AWD-Kit\\traffic\\llm.json（base_url/api_key/model）后重试。"
    try:
        return c.chat(prompt, system=system or None)
    except Exception as e:
        return f"调用失败：{e}"


@mcp.tool()
def analyze_capture(path: str, use_llm: bool = True, top: int = 12, only_suspicious: bool = False) -> str:
    """分析 capture.py 抓到的 JSONL：攻击类型分布、攻击者画像、我方被打的接口、高危 payload。
    会写出 report.md / report.json 到 traffic 目录。

    Args:
        path: capture.py 输出的 jsonl 路径（可先用 awd.py pull 把靶机上的拉回本机）
        use_llm: 是否叠加 LLM 深度解读（需要 llm.json 已配置）
        top: 送给 LLM 的样本条数
        only_suspicious: 只统计命中攻击特征的请求
    """
    if not os.path.exists(path):
        return f"找不到文件：{path}"
    rows = analyze.load(path)
    if only_suspicious:
        rows = [r for r in rows if analyze.classify(r)]
    if not rows:
        return "抓包文件里没有 HTTP 请求记录。"
    by_src, tags, paths = analyze.build(rows)
    notes = analyze.llm_report(by_src, tags, paths, top) if (use_llm and llm.LLM().ready) else None
    md = os.path.join(TRAFFIC, "report.md")
    text = analyze.write_report(by_src, tags, paths, md, notes)
    # 控制返回体积：给摘要 + 报告路径
    head = "\n".join(text.splitlines()[:60])
    return f"{head}\n\n…（完整报告：{md}）"


@mcp.tool()
def list_payloads(path: str, min_score: int = 6, top: int = 20, grep: str = "") -> str:
    """列出抓包中可复用的高分 payload（不发送）。

    Args:
        path: 抓包 jsonl
        min_score: 最低可疑分（6 起，越高越可能是真攻击）
        top: 返回条数
        grep: 可选正则，只列 path/body 匹配的
    """
    if not os.path.exists(path):
        return f"找不到文件：{path}"
    import re
    rows = replay.load(path)
    rows = [r for r in rows if r["_score"] >= min_score]
    if grep:
        rx = re.compile(grep, re.I)
        rows = [r for r in rows if rx.search(r.get("path", "")) or rx.search(r.get("body", ""))]
    rows.sort(key=lambda r: -r["_score"])
    out = []
    for i, r in enumerate(rows[:top], 1):
        out.append(f"[{i}] score={r['_score']} {'/'.join(r['_tags'])[:30]} {r['method']} {r['path'][:70]}")
        if r.get("body"):
            out.append(f"    body: {r['body'][:160]}")
    return "\n".join(out) or f"没有 score>={min_score} 的 payload"


@mcp.tool()
def replay_payloads(path: str, targets: list[str], top: int = 10, min_score: int = 6,
                    match: str = r"flag\{|uid=|root:", confirm: bool = False) -> str:
    """把抓到的对手 payload 重放给其他队伍（AWD 同源码，复用率很高）。

    Args:
        path: 抓包 jsonl
        targets: 目标列表，如 ["10.10.1.2", "10.10.1.3:8080"]
        top: 取前 N 条高分 payload
        min_score: 最低可疑分
        match: 响应命中特征正则，默认抓 flag / id 回显
        confirm: 必须显式传 true 才会真的发包（防止误触）
    """
    if not confirm:
        return "未执行：这是会真实发包的操作。确认目标无误后，用 confirm=True 重新调用。"
    if not os.path.exists(path):
        return f"找不到文件：{path}"
    import concurrent.futures as futures
    rows = [r for r in replay.load(path) if r["_score"] >= min_score]
    rows.sort(key=lambda r: -r["_score"])
    rows = rows[:top]
    tl = [t for t in (replay.parse_target(x) for x in targets) if t]
    if not tl:
        return "targets 为空"
    hits, lines = 0, []
    with futures.ThreadPoolExecutor(8) as ex:
        futs = {ex.submit(replay.send, r, t, 8, match): (r, t) for r in rows for t in tl}
        for fu in futures.as_completed(futs):
            r, t = futs[fu]
            res = fu.result()
            if res["hit"]:
                hits += 1
            lines.append(f"[{res['status']}] {t['host']} {r['method']} {r['path'][:50]} -> {res['snippet'][:80]}")
    return f"共 {len(rows)*len(tl)} 次请求，命中 {hits}\n" + "\n".join(lines[:60])


if __name__ == "__main__":
    mcp.run()
