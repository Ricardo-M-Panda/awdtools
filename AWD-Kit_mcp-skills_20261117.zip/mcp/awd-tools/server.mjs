#!/usr/bin/env node
/**
 * awd-tools MCP server
 * 把 AWD-Kit 里的常用武器封装成 MCP 工具，供 DSH / Claude / 任意 MCP 客户端调用。
 *
 * 传输: stdio
 * 启动: <kit>\00-runtime\node\node.exe <kit>\mcp\awd-tools\server.mjs
 */
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { spawn } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const KIT = path.resolve(__dirname, '..', '..');
const PY = path.join(KIT, '00-runtime', 'python', 'python.exe');
const NODE = path.join(KIT, '00-runtime', 'node', 'node.exe');
const NMAP = [
  path.join(KIT, '01-recon', 'nmap', 'nmap.exe'),
  'C:\\Program Files\\Nmap\\nmap.exe',
].find((p) => existsSync(p)) || path.join(KIT, '01-recon', 'nmap', 'nmap.exe');
const FFUF = path.join(KIT, '02-web', 'ffuf', 'ffuf.exe');
const NUCLEI = path.join(KIT, '01-recon', 'nuclei', 'nuclei.exe');
const SEMGREP = path.join(KIT, '00-runtime', 'python', 'Scripts', 'semgrep.exe');
const AWD_PY = path.join(KIT, '08-awd', 'awd.py');
const CFG = path.join(KIT, '08-awd', 'config.json');

function readCfg() {
  for (const p of [CFG, path.join(KIT, '08-awd', 'config.example.json')]) {
    if (existsSync(p)) return JSON.parse(readFileSync(p, 'utf8'));
  }
  return {};
}

/** 运行命令，收集输出（带超时） */
function run(bin, args, { timeout = 180000, cwd = KIT, input = null } = {}) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    let out = '';
    let err = '';
    let child;
    try {
      child = spawn(bin, args, { cwd, windowsHide: true });
    } catch (e) {
      return resolve({ code: -1, out: '', err: String(e), ms: 0 });
    }
    const timer = setTimeout(() => {
      try { child.kill('SIGKILL'); } catch {}
      err += `\n[timeout after ${timeout}ms]`;
    }, timeout);
    child.stdout.on('data', (d) => { if (out.length < 400000) out += d.toString(); });
    child.stderr.on('data', (d) => { if (err.length < 100000) err += d.toString(); });
    child.on('error', (e) => { clearTimeout(timer); resolve({ code: -1, out, err: err + String(e), ms: Date.now() - t0 }); });
    child.on('close', (code) => {
      clearTimeout(timer);
      resolve({ code, out, err, ms: Date.now() - t0 });
    });
    if (input) child.stdin.end(input);
  });
}

function text(s) { return { content: [{ type: 'text', text: s }] }; }
function fail(s) { return { content: [{ type: 'text', text: s }], isError: true }; }

const server = new McpServer({ name: 'awd-tools', version: '1.0.0' });

/* ------------------------------------------------------------------ nmap */
server.tool(
  'recon_nmap',
  '对目标做端口/服务扫描（nmap -sV，默认常见端口，自动 -Pn 跳过 ping）',
  {
    target: z.string().describe('IP 或域名'),
    ports: z.string().optional().describe('端口范围，如 1-65535 或 80,443,3306，默认 --top-ports 1000'),
    scripts: z.string().optional().describe('额外 nmap 脚本，如 "vuln" 或 "http-title"'),
  },
  async ({ target, ports, scripts }) => {
    const args = ['-sV', '-Pn', '-T4', '--open', target];
    if (ports) args.push('-p', ports); else args.push('--top-ports', '1000');
    if (scripts) args.push('--script', scripts);
    const r = await run(NMAP, args, { timeout: 600000 });
    return text(`$ nmap ${args.join(' ')}\n(rc=${r.code}, ${(r.ms / 1000).toFixed(1)}s)\n\n${r.out}\n${r.err}`);
  }
);

/* ------------------------------------------------------------------ ffuf */
server.tool(
  'web_ffuf',
  '目录/文件爆破。URL 中必须含 FUZZ 占位符；默认使用 kit 内置字典（缺失时回退到指定 wordlist）',
  {
    url: z.string().describe('如 http://10.0.0.5/FUZZ'),
    wordlist: z.string().optional().describe('字典路径，默认 02-web\\wordlist\\common.txt'),
    filterCodes: z.string().optional().describe('过滤状态码，如 404，默认 "404"'),
    extra: z.string().optional().describe('附加参数，原样追加，如 "-e .php,.bak"'),
  },
  async ({ url, wordlist, filterCodes, extra }) => {
    const wl = wordlist || path.join(KIT, '02-web', 'wordlist', 'common.txt');
    if (!existsSync(wl)) return fail(`字典不存在: ${wl}\n请先放置字典，或用 wordlist 参数指定。`);
    const args = ['-u', url, '-w', wl, '-fc', filterCodes || '404', '-t', '50', '-s'];
    if (extra) args.push(...extra.split(/\s+/).filter(Boolean));
    const r = await run(FFUF, args, { timeout: 600000 });
    return text(`$ ffuf ${args.join(' ')}\n(rc=${r.code})\n\n${r.out}\n${r.err}`);
  }
);

/* ---------------------------------------------------------------- nuclei */
server.tool(
  'web_nuclei',
  '用 nuclei 模板扫描目标（默认 critical,high,medium）',
  {
    target: z.string().describe('URL 或主机'),
    severity: z.string().optional().describe('默认 critical,high,medium'),
    tags: z.string().optional().describe('如 cve,rce,uploads'),
  },
  async ({ target, severity, tags }) => {
    const args = ['-u', target, '-severity', severity || 'critical,high,medium', '-silent', '-no-color', '-stats'];
    if (tags) args.push('-tags', tags);
    const r = await run(NUCLEI, args, { timeout: 900000 });
    return text(`$ nuclei ${args.join(' ')}\n(rc=${r.code})\n\n${r.out}\n${r.err}`);
  }
);

/* ------------------------------------------------------------ HTTP 请求 */
server.tool(
  'http_request',
  '原始 HTTP 请求（走或不走代理），用于手工验证漏洞、读 flag、测越权。自动跟随重定向可用 redirect 控制',
  {
    url: z.string(),
    method: z.string().optional().describe('默认 GET'),
    headers: z.record(z.string()).optional(),
    body: z.string().optional(),
    redirect: z.boolean().optional().describe('默认 false，便于观察 302'),
    timeoutMs: z.number().optional(),
  },
  async ({ url, method, headers, body, redirect, timeoutMs }) => {
    const t0 = Date.now();
    try {
      const res = await fetch(url, {
        method: method || 'GET',
        headers: headers || {},
        body: method && method.toUpperCase() !== 'GET' ? body : undefined,
        redirect: redirect ? 'follow' : 'manual',
        signal: AbortSignal.timeout(timeoutMs || 20000),
      });
      const txt = await res.text();
      const hdrs = [...res.headers.entries()].map(([k, v]) => `${k}: ${v}`).join('\n');
      return text(`HTTP ${res.status} ${res.statusText}  (${Date.now() - t0}ms)\n${hdrs}\n\n${txt.slice(0, 20000)}${txt.length > 20000 ? '\n...[truncated]' : ''}`);
    } catch (e) {
      return fail(`请求失败: ${e}`);
    }
  }
);

/* ---------------------------------------------------------------- 收 flag */
server.tool(
  'flag_collect',
  '并发从 config.json 里所有靶机读取 flag（走 awd.py collect）',
  {},
  async () => {
    const r = await run(PY, [AWD_PY, 'collect', '-c', CFG], { timeout: 180000 });
    return text(`${r.out}\n${r.err}`);
  }
);

/* ---------------------------------------------------------------- 交 flag */
server.tool(
  'flag_submit',
  '直接提交一个 flag 到平台（读 config.json 的 submit 配置）',
  { flag: z.string().describe('完整 flag 字符串') },
  async ({ flag }) => {
    const cfg = readCfg();
    const sub = cfg.submit;
    if (!sub || !sub.url) return fail('config.json 里没有 submit.url');
    const payload = { [sub.field || 'flag']: flag, ...(sub.extra || {}) };
    try {
      const res = await fetch(sub.url, {
        method: sub.method || 'POST',
        headers: { 'Content-Type': 'application/json', ...(sub.headers || {}), ...(sub.token_header ? { [sub.token_header]: sub.token } : {}) },
        body: JSON.stringify(payload),
      });
      const txt = await res.text();
      return text(`HTTP ${res.status}\n${txt.slice(0, 2000)}`);
    } catch (e) {
      return fail(`提交失败: ${e}`);
    }
  }
);

/* ------------------------------------------------------- 批量靶机命令 */
server.tool(
  'target_exec',
  '在所有靶机上批量执行一条 shell 命令（打补丁 / 查后门 / 改权限），结果按主机汇总',
  { cmd: z.string().describe('要执行的命令') },
  async ({ cmd }) => {
    const r = await run(PY, [AWD_PY, 'exec', '-c', CFG, '-C', cmd], { timeout: 300000 });
    return text(`${r.out}\n${r.err}`);
  }
);

/* --------------------------------------------------- semgrep 源码审计 */
server.tool(
  'semgrep_scan',
  '用 semgrep 静态扫描源码找漏洞（SQLi/RCE/路径穿越/反序列化等）。AWD 拿到源码后第一件事就跑这个',
  {
    dir: z.string().describe('源码目录'),
    config: z.string().optional().describe('规则集，默认 auto（自动按语言选）；也可 p/php、p/python、p/java、p/secrets'),
    severity: z.string().optional().describe('过滤等级，如 ERROR / WARNING'),
  },
  async ({ dir, config, severity }) => {
    const args = ['--config', config || 'auto', '--json', '--quiet', '--disable-version-check', dir];
    if (severity) args.push('--severity', severity);
    const r = await run(SEMGREP, args, { timeout: 900000 });
    let findings = [];
    try {
      const j = JSON.parse(r.out);
      findings = (j.results || []).map((x) => ({
        rule: x.check_id,
        file: x.path,
        line: x.start && x.start.line,
        msg: (x.extra && x.extra.message || '').slice(0, 300),
      }));
    } catch {
      return text(`semgrep 输出无法解析（rc=${r.code}）\n${r.out.slice(0, 2000)}\n${r.err.slice(0, 1000)}`);
    }
    if (!findings.length) return text(`未发现明显问题（扫描 ${dir}）`);
    const lines = findings.map((f, i) => `${i + 1}. [${f.rule}] ${f.file}:${f.line}\n   ${f.msg}`);
    return text(`发现 ${findings.length} 处可疑：\n\n` + lines.join('\n\n'));
  }
);

/* --------------------------------------------------- webshell 静态扫描 */server.tool(
  'webshell_scan',
  '扫描目录里的 webshell（蚁剑/冰蝎/哥斯拉/一句话），按可疑度排序',
  {
    dir: z.string(),
    sinceMinutes: z.number().optional().describe('只扫 N 分钟内修改过的文件'),
  },
  async ({ dir, sinceMinutes }) => {
    const args = [path.join(KIT, '08-awd', 'webshell_scan.py'), '-d', dir];
    if (sinceMinutes) args.push('--since', String(sinceMinutes));
    const r = await run(PY, args, { timeout: 300000 });
    return text(`${r.out}\n${r.err}`);
  }
);

/* ------------------------------------------------------------------ 信息 */
server.tool('kit_info', '查看 AWD-Kit 布局、运行时版本、config 路径', {}, async () => {
  const lines = [`KIT = ${KIT}`, `python = ${PY} (${existsSync(PY) ? 'ok' : 'MISSING'})`, `node = ${NODE} (${existsSync(NODE) ? 'ok' : 'MISSING'})`];
  for (const [k, p] of Object.entries({ nmap: NMAP, ffuf: FFUF, nuclei: NUCLEI, awd_py: AWD_PY, config: CFG })) {
    lines.push(`${k.padEnd(8)} = ${p} (${existsSync(p) ? 'ok' : 'MISSING'})`);
  }
  const cfg = readCfg();
  lines.push(`targets = ${(cfg.targets || []).length} 个`);
  return text(lines.join('\n'));
});

const transport = new StdioServerTransport();
await server.connect(transport);
