# 可选：把 rea（Reverse Engineer Anything）的 MCP 挂到 DSH
# 注意：rea 暴露 255 个工具，会明显占用上下文，默认不启用。
# 用法: powershell -ExecutionPolicy Bypass -File enable-rea.ps1
#       powershell -ExecutionPolicy Bypass -File enable-rea.ps1 -Remove
param([switch]$Remove)

$ErrorActionPreference = 'Stop'
$Kit  = Split-Path $PSScriptRoot -Parent
$Node = Join-Path $Kit '00-runtime\node\node.exe'
$Disp = Join-Path $Kit '00-runtime\node-global\node_modules\rea-agents\scripts\rea.mjs'
$Patch = Join-Path $env:USERPROFILE '.dsh\profiles\desktop\cordis.patch.yml'

$marker = '# >>> awd-kit rea >>>'
$end    = '# <<< awd-kit rea <<<'

if (-not (Test-Path $Patch)) { throw "找不到 profile patch: $Patch" }
$text = Get-Content $Patch -Raw -Encoding UTF8

if ($Remove) {
    if ($text -match [regex]::Escape($marker)) {
        $text = [regex]::Replace($text, "(?s)\r?\n?" + [regex]::Escape($marker) + ".*?" + [regex]::Escape($end), '')
        Copy-Item $Patch "$Patch.bak-$(Get-Date -f yyyyMMddHHmmss)" -Force
        Set-Content $Patch $text -Encoding UTF8
        "已移除 rea MCP。"
    } else { "未启用 rea MCP。" }
    return
}

if (-not (Test-Path $Disp)) { throw "rea 未安装：$Disp（先 npm i -g rea-agents --prefix ...）" }
if ($text -match [regex]::Escape($marker)) { "rea MCP 已启用，无需重复。"; return }

$block = @"

$marker
- insert:
    - id: rea-mcp
      name: '@deepseek-ai/dsh-mcp-client'
      config:
        serverName: rea
        transport: stdio
        command: '$($Node.Replace('\','/'))'
        args:
          - '$($Disp.Replace('\','/'))'
          - 'mcp'
        failOnStartupError: false
$end
"@

Copy-Item $Patch "$Patch.bak-$(Get-Date -f yyyyMMddHHmmss)" -Force
Add-Content -Path $Patch -Value $block -Encoding UTF8
"已启用 rea MCP（255 个工具）。重启 DSH 后出现 mcp__rea__* 。"
"提示：工具太多会占上下文，比赛不搞二进制逆向就建议 -Remove 掉。"
