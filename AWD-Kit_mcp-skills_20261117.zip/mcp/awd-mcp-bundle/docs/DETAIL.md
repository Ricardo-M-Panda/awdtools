# AWD-Kit MCP

把 `AWD-Kit` 的武器库封装成 MCP 工具，供 DeepSeek Harness 通过 `@deepseek-ai/dsh-mcp-client` 以 stdio 方式连接。

## 提供的工具（serverName = `awd-tools`）

| 工具 | 作用 |
|---|---|
| `recon_nmap` | 端口 / 服务扫描 |
| `web_ffuf` | 目录与文件爆破 |
| `web_nuclei` | 模板化 POC 扫描 |
| `http_request` | 原始 HTTP 请求（验证漏洞、读 flag、测越权） |
| `flag_collect` | 并发读取所有靶机 flag（走 `08-awd/awd.py`） |
| `flag_submit` | 直接提交一个 flag |
| `target_exec` | 在所有靶机上批量执行命令 |
| `webshell_scan` | 扫蚁剑 / 冰蝎 / 哥斯拉 / 一句话 |
| `kit_info` | 自检：运行时与路径是否就位 |

## 安装

```powershell
powershell -ExecutionPolicy Bypass -File install-mcp.ps1      # 写入 profile patch
# 卸载
powershell -ExecutionPolicy Bypass -File install-mcp.ps1 -Remove
```

脚本会把下面这段 append 到 `%USERPROFILE%\.dsh\profiles\desktop\cordis.patch.yml`（自动先备份 `.bak-<时间戳>`）：

```yaml
- insert:
    - id: awd-tools-mcp
      name: '@deepseek-ai/dsh-mcp-client'
      config:
        serverName: awd-tools
        transport: stdio
        command: '<kit>/00-runtime/node/node.exe'
        args: ['<kit>/mcp/awd-tools/server.mjs']
        failOnStartupError: false
```

重启 DSH 后调用 `mcp__awd-tools__kit_info` 验证。

## 手动验证（不依赖 DSH）

```powershell
& "<kit>\00-runtime\node\node.exe" "<kit>\mcp\awd-tools\server.mjs"
# 粘贴一行 JSON-RPC：
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}
```

## 另一种方式：bundle

`awd-mcp-bundle/` 是等价的 configuration-only bundle，可用 `plugin_manager` 的 `install_bundle` 安装（需要 DSH 侧支持本地路径安装）。patch 方式更直接，二者选一即可。
