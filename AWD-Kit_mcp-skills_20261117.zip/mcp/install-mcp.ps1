﻿# 把 AWD-Kit 的全部 MCP server 挂到当前 DSH profile
# 用法: powershell -ExecutionPolicy Bypass -File install-mcp.ps1
#       powershell -ExecutionPolicy Bypass -File install-mcp.ps1 -Remove
#       powershell -ExecutionPolicy Bypass -File install-mcp.ps1 -Only awd-tools,awd-llm
param([switch]$Remove, [string[]]$Only)

$ErrorActionPreference = 'Stop'
$Kit   = Split-Path $PSScriptRoot -Parent          # 本脚本在 <kit>\mcp\ 下
$Node  = Join-Path $Kit '00-runtime\node\node.exe'
$Py    = Join-Path $Kit '00-runtime\python\python.exe'
$Scr   = Join-Path $Kit '00-runtime\python\Scripts'
$Patch = Join-Path $env:USERPROFILE '.dsh\profiles\desktop\cordis.patch.yml'

function P([string]$p) { $p.Replace('\', '/') }

$servers = @(
    @{ id = 'awd-tools-mcp';  name = 'awd-tools';     cmd = $Node;                     args = @((P (Join-Path $Kit 'mcp\awd-tools\server.mjs'))); env = @{} }
    @{ id = 'awd-llm-mcp';    name = 'awd-llm';       cmd = $Py;                       args = @((P (Join-Path $Kit 'mcp\awd-llm\server.py')));     env = @{ PYTHONIOENCODING = 'utf-8' } }
    @{ id = 'ghidra-mcp';     name = 'ghidra';        cmd = (Join-Path $Scr 'ghidra-mcp.exe');    args = @(); env = @{} }
    @{ id = 'wireshark-mcp';  name = 'wireshark';     cmd = (Join-Path $Scr 'wireshark-mcp.exe'); args = @(); env = @{
            TSHARK_PATH = (P (Join-Path $Kit '03-binary\wireshark\tshark.exe'))
            PATH = ((P (Join-Path $Kit '03-binary\wireshark')) + ';%PATH%') } }
    @{ id = 'frida-mcp';      name = 'frida';         cmd = (Join-Path $Scr 'frida-mcp-server.exe'); args = @(); env = @{} }
    @{ id = 'r2-mcp';         name = 'radare2';       cmd = (Join-Path $Kit 'mcp\vendor\r2mcp\r2mcp.exe'); args = @(); env = @{
            PATH = ((P (Join-Path $Kit '03-binary\radare2\bin')) + ';%PATH%') } }
    @{ id = 'memory-mcp';     name = 'memory';        cmd = $Node;                     args = @((P (Join-Path $Kit '00-runtime\node-global\node_modules\@modelcontextprotocol\server-memory\dist\index.js'))); env = @{
            MEMORY_FILE_PATH = (P (Join-Path $Kit 'mcp\memory.jsonl')) } }
    @{ id = 'chrome-devtools-mcp'; name = 'chrome';   cmd = $Node;                     args = @(
            (P (Join-Path $Kit '00-runtime\node-global\node_modules\chrome-devtools-mcp\out\Default\gen\src\bin\chrome-devtools-mcp.js')),
            '--executablePath', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
            '--isolated'); env = @{} }
)

if (-not (Test-Path $Patch)) { throw "找不到 profile patch: $Patch" }
$text = Get-Content $Patch -Raw -Encoding UTF8
$marker = '# >>> awd-kit mcp >>>'
$end    = '# <<< awd-kit mcp <<<'

if ($Remove) {
    if ($text -match [regex]::Escape($marker)) {
        $text = [regex]::Replace($text, "(?s)\r?\n?" + [regex]::Escape($marker) + ".*?" + [regex]::Escape($end), '')
        Copy-Item $Patch "$Patch.bak-$(Get-Date -f yyyyMMddHHmmss)" -Force
        Set-Content $Patch $text -Encoding UTF8
        "已移除 AWD-Kit MCP 配置。"
    } else { "未找到 AWD-Kit MCP 配置。" }
    return
}

# 已经写过就先删掉重写
if ($text -match [regex]::Escape($marker)) {
    $text = [regex]::Replace($text, "(?s)\r?\n?" + [regex]::Escape($marker) + ".*?" + [regex]::Escape($end), '')
}

$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine()
[void]$sb.AppendLine($marker)
[void]$sb.AppendLine('- insert:')
foreach ($s in $servers) {
    if ($Only -and ($Only -notcontains $s.name)) { continue }
    if ($s.cmd -and -not (Test-Path $s.cmd)) {
        Write-Warning "跳过 $($s.name)：找不到 $($s.cmd)"
        continue
    }
    [void]$sb.AppendLine("    - id: $($s.id)")
    [void]$sb.AppendLine("      name: '@deepseek-ai/dsh-mcp-client'")
    [void]$sb.AppendLine("      config:")
    [void]$sb.AppendLine("        serverName: $($s.name)")
    [void]$sb.AppendLine("        transport: stdio")
    [void]$sb.AppendLine("        command: '$(P $s.cmd)'")
    if ($s.args.Count -gt 0) {
        [void]$sb.AppendLine("        args:")
        foreach ($a in $s.args) { [void]$sb.AppendLine("          - '$a'") }
    }
    if ($s.env.Count -gt 0) {
        [void]$sb.AppendLine("        env:")
        foreach ($k in $s.env.Keys) { [void]$sb.AppendLine("          ${k}: '$(P $s.env[$k])'") }
    }
    [void]$sb.AppendLine("        failOnStartupError: false")
}
[void]$sb.AppendLine($end)

Copy-Item $Patch "$Patch.bak-$(Get-Date -f yyyyMMddHHmmss)" -Force
Set-Content -Path $Patch -Value ($text.TrimEnd() + "`n" + $sb.ToString()) -Encoding UTF8
"已写入 $Patch"
"重启 DSH（或等它热加载）后会出现 mcp__awd-tools__* / mcp__awd-llm__* / mcp__ghidra__* / mcp__wireshark__* / mcp__frida__* 工具。"
